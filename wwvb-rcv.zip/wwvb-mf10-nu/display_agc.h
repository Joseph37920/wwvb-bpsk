// display_agc.h

// void display_agc(void);
void display_LP(void);
void display_noise(void);
void display_pll(void);
void display_Vt(void);
void tty_display_digits(int x);
void tty_display_gigits_no_cr(int x);




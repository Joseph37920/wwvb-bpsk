// pwm.h --------

void init_pwm(void);	// setup pwm1
void load_pwm(int v);	// load value 0 - 1024


#define pwm_period 0xff	// valid for prescaler 1,4, and 16
// lcd_cntl.h

// define the function prototypes

void init_lcd(void);
void write_data_lcd(char x);
void rom_message_lcd(rom char* x);
void ram_message_lcd(ram char* x);
void write_control_lcd(char x);
void set_data_address_lcd(int a);
void wait_busy_lcd(void);
void cleanup_lcd(void);


/* ----------------------------------------------------- */

// Commands for the LCD

#define TURN_ON_POWER 0x1c
#define TURN_ON_DISPLAY 0x14
#define SET_TWO_LINE 0x28
#define SET_DARK_CONTRAST 0x4f
#define SET_ADDRESS_ZERO 0xe0
#define START_OSC 0x03
#define CLEAR_DISPLAY 1
#define RETURN_CURSOR_TO_ZERO 2
#define SET_ADDRESS_LOW 0xe0
#define SET_ADDRESS_HIGH 0xc0 


#ifndef _COMMFUNC
#define _COMMFUNC

#include "integer.h"

void uart_init (void);
int uart_test (void);
void uart_put (BYTE);
BYTE uart_get (void);
int test_RX(void);

void DI(void);
void EI(void);



void blip14(void);
void blip_delay(void);

// define the interupt enable bit for now

#define GIE 7	// this ought to be in a header somewhere






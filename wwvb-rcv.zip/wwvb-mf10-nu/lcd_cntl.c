// lcd_cmd.c  - full control for the LCD display


#include <p18f2620.h>
#include "lcd_cntl.h"
#include "comm.h"
// the following pins are allocated for the display

/*
	Data Pins
	RB0 21
	RB1 22
	RB2 23
	RB3 24
	RB4 25
	RB5 26	- PGM pin in program mode of some sort
	RB6 27	- Program Clock from PicKit2
	RB7 28	- Program Data from PicKit2

	Control Pins
	RC0 11	- Enable ( what passes for a clock )
	RC4 15	- Read/~Write (multiplex line control)
	RC5 16	- R/S Register select: true = data, false = command
*/

#define SELECT_COMMAND	PORTCbits.RC5 = 0;
#define SELECT_DATA	PORTCbits.RC5 = 1;

#define READ		PORTCbits.RC4 = 1;
#define WRITE		PORTCbits.RC4 = 0;

#define CLOCK_HIGH	PORTCbits.RC0 = 1;
#define CLOCK_LOW		PORTCbits.RC0 = 0;

#define COMMAND_DELAY 2000
#define DATA_DELAY 25	 


//----------- local prototypes ------------------------
void clock(void);
void clock_delay(void);
void data_delay(int x);


// ------------------ init the LCK -------------------==

void init_lcd()
{
// perform a reset first
data_delay(5*COMMAND_DELAY); // wait for LCD to to POR
PORTAbits.RA4 = 0;	// zero is ground (reset)
data_delay(5*COMMAND_DELAY);
PORTAbits.RA4 = 1;	// back to reset not
// start rest of initialization sequence
data_delay(5*COMMAND_DELAY);
SELECT_COMMAND
WRITE
PORTB = TURN_ON_POWER;
clock();
data_delay(COMMAND_DELAY);
PORTB = START_OSC;
clock();
data_delay(3*COMMAND_DELAY);
PORTB = TURN_ON_DISPLAY;
clock();
data_delay(COMMAND_DELAY);
PORTB = SET_TWO_LINE;
clock();
data_delay(COMMAND_DELAY);
PORTB = SET_DARK_CONTRAST;
clock();
data_delay(COMMAND_DELAY);
PORTB = SET_ADDRESS_ZERO;
clock();
data_delay(COMMAND_DELAY);
}

// ==================== write data to display --------------
void write_data_lcd(char c)
{
SELECT_DATA
WRITE
PORTB = c;
clock();
wait_busy_lcd();
}


// --------------------- write control to display --------
void write_control_lcd(char c)
{
SELECT_COMMAND
WRITE
PORTB = c;
clock();
wait_busy_lcd();
}

// ----------- set data address -------------------------
void set_data_address_lcd(int a)
{
char cmd;
	cmd = ((a >>5) & 0x0003) + SET_ADDRESS_HIGH;
	write_control_lcd(cmd);
	cmd = (a & 0x001f) + SET_ADDRESS_LOW;
	write_control_lcd(cmd);
} // end set data address
// --------------------- write messsage from rom to display ----
void rom_message_lcd(rom near char* x)
{
	rom near char *t_ptr;
	t_ptr = x;
	while(*t_ptr)
	{
		write_data_lcd(*t_ptr++);
	}
} // end rom message

// ------------- write message from ram to display -----------
void ram_message_lcd(ram char* x)
{
	ram char *t_ptr;
	t_ptr = x;
	while(*t_ptr)write_data_lcd(*t_ptr++);
} // end ram message

void cleanup_lcd(void)
{
		write_control_lcd(CLEAR_DISPLAY);
		write_control_lcd(RETURN_CURSOR_TO_ZERO);
}

// -------------------- read busy signal from LCD
void wait_busy_lcd(void)
{
	char tst;
	TRISB = 0xff;	// make data lines input
	SELECT_COMMAND	// R/S = 0
	READ			// R/~W = 1
/*
	The logic of the LCD display is asynchronus
	The chip is Hitachi HD66717
	Raising the "ENABLE" gates the busy line contionusly
*/
	CLOCK_HIGH		// Enable high
	CLOCK_HIGH		// wait for rise time
wait_loop:
	if(PORTBbits.RB7)goto wait_loop;
	// restore port direction and clock
	CLOCK_LOW
	WRITE
	TRISB = 0x0;
} // end of wait_busy


// -------------- clock data or command -----------------
void clock()
{
CLOCK_HIGH
clock_delay();
CLOCK_LOW
}

// --------------- delay for the clock to rise etc.

void clock_delay()
{
int i;
for(i=10;i==0;i++);
}

// ------------------- data delay = 1 Msec ----------------
void data_delay(int x) // used to generate longer delay (LCD)
{
int i;
 for(i=0;i<x;i++);
}

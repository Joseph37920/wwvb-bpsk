// display_agc - display the agc reading

#include <string.h>
#include <p18f2620.h>
#include "stdlib.h"
#include "stdio.h"
#include "comm.h"
#include "lcd_cntl.h"
#include "main.h"

#include "display_agc.h"

extern int agc_voltage;	// in main

extern char dsp_string[25];
#define size_of_string_buffer 25

char string[size_of_string_buffer];        // string to tty

// display the AGC voltage
#ifdef display_agc_code
// removed the AGC reading to replace it with the Q_signal
void display_agc()
{
	sprintf(dsp_string,
		"AGC Voltage %4i",
			agc_voltage
				);
	cleanup_lcd();
	ram_message_lcd(dsp_string);
} // end display_agc
#endif

// display the LP filter static voltage

extern int lp_voltage;
extern int lp_count;
void display_LP()
{
	sprintf(dsp_string,
		"Low Pass Voltage %4i",
			lp_voltage
				);
	cleanup_lcd();
	ram_message_lcd(dsp_string);
} // end display_LP

// display noise

extern int d_noise;

void display_noise()
{
    d_noise = d_noise/lp_count;
	sprintf(dsp_string,
		"Noise Sum %5i",
			d_noise
				);
	cleanup_lcd();
	ram_message_lcd(dsp_string);
} // end display_LP

// display variance

extern int dsp_variance;
extern int pll_state;

void display_pll()
{
	sprintf(dsp_string,
		"Pll State %1i Var. %3i",
			pll_state,
			dsp_variance
				);
	cleanup_lcd();
	ram_message_lcd(dsp_string);
} // end display_LP

// display Tuning Voltage

extern long phase_sum;

void display_Vt()
{
	int lcl_phase;
	lcl_phase = (int) phase_sum;
	sprintf(dsp_string,
		"Vt = %5i",
		lcl_phase
		);
	cleanup_lcd();
	ram_message_lcd(dsp_string);

} // end display Vt

void tty_display_digits(int x)
{
    char c;
    int i;
    sprintf(string,
            "%d\n",
            x);
    for(i=0;i<size_of_string_buffer;i++){
        if(string[i])uart_put(string[i]);
        else break;
    }
}   // end of display digit

void tty_display_digits_no_cr(int x)
{
    char c;
    int i;
    sprintf(string,
            "%d ",
            x);
    for(i=0;i<size_of_string_buffer;i++){
        if(string[i])uart_put(string[i]);
        else break;
    }



}   // end display digit with no cr



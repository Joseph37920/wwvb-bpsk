// pwm.c --------- routines to use the PWM1
#include "pwm.h"
#include <p18f2620.h>
// the registers that control CCP1 aka PWM1 are
// CCP1CON - holds the mode bits and the last 2 bits of duty cycle
//			CCP1CON.CCP1M3 = 1	
//			CCP1CON.CCP1M2 = 1
//
//			CCP1CON.DC1B1 = LS bit 1
//			CCP1CON.DC1B2 = LS bit 2
//			the other 8 bits are in CCP1RL

// Timer 2 is used to control the CCP1 module
// CCP1 has output on RC2 pin (13) and TRISC must cleared
//	for bit RC2

// For basic setup info see section 15.4 PWM Mode in
// the PIC manusl for the 2620
// the setup sequence is given in section 15.4.4


void init_pwm(void)
{
	PR2 = pwm_period;		// a define see PWM header
	// init with a 50% duty cycle ( 512 count)
	CCPR1L = (512 >>2); 	// ls two bits go into
	CCP1CONbits.DC1B1 =0;
	CCP1CONbits.DC1B0 =0;
	TRISCbits.RC2 = 0;		// set output to RC2 (pin 13)
	T2CONbits.T2CKPS0 =0;	// set prescaler to 1
	T2CONbits.T2CKPS1 =0;	
	T2CONbits.TMR2ON  =1;	// turn on timer 2
	CCP1CONbits.CCP1M0 =0;	// configure PWM 1
	CCP1CONbits.CCP1M1 =0;
	CCP1CONbits.CCP1M2 =1;
	CCP1CONbits.CCP1M3 =1;
}

// ----------- load PWM ------------------------

void load_pwm(int v)
{
	CCP1CONbits.DC1B1 =v & 2;	// load ls bits (two)
	CCP1CONbits.DC1B0 =v & 1;
	CCPR1L = (v >>2);       	// load rest into period reg.
}
	 
//display_time.h

void init_display_time(void);
void display_time(void);
void format_and_display(void);
void update_time(void);
void force_update_time(void);
void convert_date(void);

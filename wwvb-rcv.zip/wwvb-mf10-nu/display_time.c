// display_time.c

#include <string.h>
#include <p18f2620.h>
#include "stdlib.h"
#include "stdio.h"
#include "comm.h"
#include "lcd_cntl.h"
#include "main.h"
#include "decode.h"
#include "display_time.h"

// ------------- external data ---------------------
// sychronized to the decode time data if it is matched
extern int tmr0_second;
extern int dsp_minutes;
extern int dsp_hours;
extern int dsp_days;
extern int dsp_year;
extern int dsp_dst;
extern char d_clock;
extern char d_signal;
extern unsigned char state;

// ------------- external reference data --------------
// this data is collected by the decode routine from
// WWVB signals - it may or may not be accurate

extern int second;	// global second count
extern int d_minutes;
extern int d_hours;
extern int d_days;
extern int d_year;
extern int d_dst;
extern char d_update;	// data received from decode tag
extern long variance_sum;
extern pll_state;
extern int lp_voltage;

// ---------------- strings --------------------------
char dsp_string[25];	// string output to the LCD
int lcl_update = 0;
int lcl_advance = 0;
int lcl_variance;

// ----------------- month and day lists --------------------
#define DAY_BUF_SIZE 3

 char day_name[7][DAY_BUF_SIZE+1] = {
   { "Sat" },
   { "Sun" },
   { "Mon" },
   { "Tue" },
   { "Wed" },
   { "Thu" },
   { "Fri" },
 };

#define MONTH_BUF_SIZE 4

char month_name[12] [MONTH_BUF_SIZE+1] = {
	{"Jan"},
	{"Feb"},
	{"Mar"},
	{"Apr"},
	{"May"},
	{"Jun"},
	{"Jul"},
	{"Aug"},
	{"Sep"},
	{"Oct"},
	{"Nov"},
	{"Dec"},
	};

const rom int days_in_month[12] = {
	31,	// January
	28, // Feb
	31, // March
	30, // April
	31, // May
	30, // June
	31, // July
	31, // August
	30, // September
	31, // October
	30, // November
	31, // December
	};

// ------------------ global values for data ----------------
int month;			// value 0 - 11  - reference month_name
int month_day;		// value 1 - 31  - just an intiger
int week_day;		// value 0 - 6	 - reference day_nameL
// ------------------- startup init of LCD --------------------
void init_display_time(void)
{
	dsp_minutes = dsp_hours = dsp_days = dsp_year = dsp_dst = 0;
	format_and_display();
} // end init_display_time

// ---------------------------------------------------

void display_time(void)
{
	if(d_update)// decode has a new time
		{
		dsp_minutes = d_minutes;
		dsp_hours = d_hours;
		dsp_days = d_days;
		dsp_year = d_year;
		dsp_dst = d_dst;
		lcl_update = d_update;
		d_update = 0;
		lcl_advance = 0;
		force_update_time();	// decode presents last minute
		}
	format_and_display();
	if(lcl_advance)update_time();
	lcl_advance = 1;
} // end display_time


void format_and_display(void)
{
	char c_dst;
	if(dsp_dst == 0) c_dst = 'S'; else c_dst = 'D';
	convert_date();	// I know once a day - we have enough cpu cycles
	lcl_variance = (int)variance_sum;
	sprintf(dsp_string,
		"%2i:%2i:%2i %s %2i %s %2i%c",
			dsp_hours,
			dsp_minutes,
			tmr0_second,
			day_name[week_day],
			month_day,
			month_name[month],
			dsp_year,
			c_dst
				);
			if(d_signal)d_signal = 0;
	cleanup_lcd();
	ram_message_lcd(dsp_string);
} // end of format and display


void update_time(void)
{
	if(tmr0_second == 59)
	{ // upddate minutes, hours, days
		dsp_minutes++;
		if(dsp_minutes >=60)
			{
			dsp_minutes = 0;
			dsp_hours++;
			if(dsp_hours >=24)
				{
				dsp_hours = 0;
				dsp_days++;
				if(dsp_days >365)
					{
						dsp_days = 0; // forget leap year for a while
					} // end dsp_days
				}// end dsp_hours
			} // end dsp_minutes
	} // end tmr0_second
} // end update_time

// ------------------ force up date by one minute -------------
void force_update_time(void)
{

//	    update minutes, hours, days
		dsp_minutes++;
		if(dsp_minutes >=60)
			{
			dsp_minutes = 0;
			dsp_hours++;
			if(dsp_hours >=24)
				{
				dsp_hours = 0;
				dsp_days++;
				if(dsp_days >365)
					{
						dsp_days = 0; // forget leap year for a while
					} // end dsp_days
				}// end dsp_hours
			} // end dsp_minutes
} // end update_time

// --------------------- calculate day of week, month and day ----------------

void convert_date(){
int i,j;
int leap_days;
int total_days;
int x_leap_year;
int tmp_days;


// input vars d_year and d_days
// output vars are month, month_day and week_day

leap_days = (d_year/4);	// number of leap days, 2000 leap year also
x_leap_year = d_year % 4;  // is the year divisable by four
if(!x_leap_year)leap_days--;	// leap days high by one on leap year
total_days = d_year * 365 + leap_days + d_days;
week_day = (total_days) % 7; // day is mod 7 of total days base zero
month = 0;
tmp_days = d_days;
// calculate the month and day number
for(i=0;i<12;i++){
	if((x_leap_year == 0)&&(i==1)){	// special case for Feb 29th
		tmp_days -= 29;
	} // end of leap year test
	else
	{
	tmp_days -= days_in_month[i];
	}

	if(tmp_days <= 0){	// end of month test
		if((x_leap_year == 0)&&(i==1)){
			tmp_days += 29;
		}
		else
			tmp_days += days_in_month[i];
		break;
	} // end of tmp_days negative
	} // end for month loop
month = i;	// save month
month_day = tmp_days;  // resisual days is day of month

}// end of convert date

// end of module

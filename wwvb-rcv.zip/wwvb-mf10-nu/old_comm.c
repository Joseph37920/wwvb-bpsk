//#include <string.h>
//#include <p18f4525.h>
#include <p18f2620.h>
#include "comm.h"
//#include "main.h"

#define BUFFER_SIZE 79
static int TxRun;
static volatile struct
{
	int		rptr;
	int		wptr;
	int		count;
	BYTE	buff[BUFFER_SIZE];
} TxFifo, RxFifo;


// have to write code to vector my own interupts here
void vector_isr(void);
// two interrupt levels
// address 08x is the low priority
// address 18x is the high priority


//#pragma code low_vector=0X18  why is this nop-ed?



#pragma code high_vector=0X08

void high_interupt(void)
{
_asm goto vector_isr _endasm
}
#pragma code

void _T1Interrupt(void);
void _U1RXInterrupt(void);
void _U1TXInterrupt (void);


#pragma interrupt vector_isr
void vector_isr(void)
{
static char bank;
bank = BSR;
if(INTCONbits.TMR0IF){INTCONbits.TMR0IF=0;_T1Interrupt();}
if(PIR1bits.TXIF) _U1TXInterrupt ();
if(PIR1bits.RCIF) _U1RXInterrupt ();
bank = bank+1;

}



void _U1RXInterrupt (void)
{
	BYTE d;
	int n;



	d = (BYTE)RCREG;
	n = RxFifo.count;
	if (n < BUFFER_SIZE) {
		n++;
		RxFifo.count = n;
		n = RxFifo.wptr;
		RxFifo.buff[n] = d;
		RxFifo.wptr = (n + 1) % BUFFER_SIZE;
	}
}




void _U1TXInterrupt (void)
{
	int n;

	n = TxFifo.count;
	if (n) {
		n--;
		TxFifo.count = n;
		n = TxFifo.rptr;

		while(!PIR1bits.TXIF); // check for still xmitting
		TXREG = TxFifo.buff[n];
		TxFifo.rptr = (n + 1) % BUFFER_SIZE;
	} else {
		TxRun = 0;
		PIE1bits.TXIE = 0; // turn off tty interupts
	}
}



int uart_test (void)
{
	return RxFifo.count;
}


int test_RX(void){return RxFifo.count;}


BYTE uart_get (void)
{
	BYTE d;
	int n;


	while (!RxFifo.count);

	n = RxFifo.rptr;
	d = RxFifo.buff[n];
	RxFifo.rptr = (n + 1) % BUFFER_SIZE;
//	DI();
	INTCONbits.PEIE = 0;		// disable peripheral interupts
	RxFifo.count--;
//	EI();
	INTCONbits.PEIE = 1;		// enable peripheral interupts
	return d;
}


void uart_put (BYTE d)
{
	int n;
	while (TxFifo.count >= BUFFER_SIZE);	// wait for space in fifo

	n = TxFifo.wptr;
	TxFifo.buff[n] = d;	// put character into fifo buffer
	TxFifo.wptr = (n + 1) % BUFFER_SIZE; // update index mod BUFFER_SIZE
	//DI();
	INTCONbits.PEIE = 0;		// disable peripheral interupts
	TxFifo.count++;
	if (!TxRun) {
		TxRun = 1;
		PIE1bits.TXIE = 1; // turn on tty interupts
	}
//	EI();
	INTCONbits.PEIE = 1;		// enable peripheral interupts
}

#endif


void uart_init (void)
{
int i;
	/* Disable Tx/Rx interruptrs */
//	_U1RXIE = 0;
	PIE1bits.RCIE = 0;
//	_U1TXIE = 0;
//	PIE1bits.TXIE = 0;
	/* Initialize UART1 */
	// setup multiplexed uart pins
	TRISC |= 0xC0; // set bits 6 & 7 of trisc high
//	U1BRG = FCY / 16 / BPS - 1;
	BAUDCON = 0; // CLEAR BAUDCON
	BAUDCONbits.BRG16 = 0; 	// set 8 bit counter
	SPBRGH = 0;	// clear high order of counter
	SPBRG = 12;	// fixed value for 8Mhz clock & 9600
	TXSTAbits.BRGH = 0; // select low speed (div by 64) mode
	TXSTAbits.SYNC = 0; // select async mode
//	_UARTEN = 1;
	RCSTAbits.SPEN = 1; // enable UART port pins
	RCSTAbits.CREN = 1; // continous RX enable
	RCSTAbits.RX9  = 0;	// select 8 bit reception
	TXSTAbits.TX9 = 0;	// select 8 bit transmission
//	_UTXEN = 1;
	TXSTAbits.TXEN =1;	// enable TX
	// fill buffer for test
	for(i=0;i<BUFFER_SIZE;i++)TxFifo.buff[i] = '#';
	
	/* Clear Tx/Rx FIFOs */
	TxFifo.rptr = TxFifo.wptr = TxFifo.count = 0;
	RxFifo.rptr = RxFifo.wptr = RxFifo.count = 0;
	TxRun = 0;

	/* Enable Tx/Rx interruptrs */
//	_U1RXIE = 1;
	PIE1bits.RCIE = 1;
//	_U1TXIE = 1;
//	PIE1bits.TXIE = 1;
}	// end uart init

//-------- debug ----------

void blip14(void)
{
 PORTCbits.RC3 = 1;
// blip_delay();		// pulse is 0.5 Usec at 8Mhz
 PORTCbits.RC3 = 0;
}



void blip_delay(void) // used to generate longer delay (LCD)
{
int i;
for(i=3;i>0;i--);
}


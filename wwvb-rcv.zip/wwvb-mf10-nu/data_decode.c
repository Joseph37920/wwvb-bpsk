// data_decode.c - input is time interval of WWVB data

 
#include "decode.h"
#include "lcd_cntl.h"
#include "stdio.h"



// local storage
unsigned char	state;

//int second;
int l_minutes;
int	l_hours;
int l_days;
int l_dut1_sign;
int l_dut1_value;
int l_year;
unsigned char	l_leap_year;
unsigned char	l_leap_second;
unsigned char	l_dst;
unsigned char	l_err;
int last_symbol;
int this_symbol;

// local helper routines -----------------------------------------
void must_be_marker(void)
{
	if(this_symbol != marker)
	{
	state = p_idle;
	l_err = 1;
	}
} // end of must be marker


// setup the case statement etc.
void init_decode()
{
extern int tmr0_second;
	state = p_idle;
	last_symbol = 0;
	tmr0_second = 0;
} // end of init

// ------------------------------------------------------------

// decode the input of times for the data signal
void data_decode(int d_time)
{
extern int d_minutes;
extern int d_hours;
extern int d_days;
extern int d_year;
extern int d_dst;
// reference time/date set
extern int d1_minutes;
extern int d1_hours;
extern int d1_days;
extern int d1_year;
extern int d1_dst;

extern char d_update;
extern int second;
extern int tmr0_second;

char data_string[20];

// decode the time to a symbol
if(d_time > m_zero) this_symbol = zero;
if(d_time > m_one) this_symbol = one;
if(d_time > m_marker) this_symbol = marker;
// last valid one wins!

if(state != p_idle) second++; // keep time within minute
switch(state){
	case p_idle:
		if((this_symbol == marker) &&
			(last_symbol == marker))
			{
			state = minutes;
			l_minutes = 0;
			second = 0;
//			tmr0_second = 0;	// global second
			l_err = 0;
			}
		break;

	case first_second:
		state = minutes;
		second = 0;
		l_minutes=l_hours=l_days=l_dut1_sign=l_dut1_value=
		l_year= 0;
		must_be_marker();
		tmr0_second = 1;	// reset display second
		break;				// received second is one sec late

	case minutes:
		// Super klutzy way to convert BCD encoded to bin 
		if(this_symbol == one)
		{
		if(second == 1) l_minutes +=40;
		if(second == 2) l_minutes +=20;
		if(second == 3) l_minutes +=10;
		if(second == 5) l_minutes +=8;
		if(second == 6) l_minutes +=4;
		if(second == 7) l_minutes +=2;
		if(second == 8) l_minutes +=1;
		}	// end of "one" symbol
		if(second == 4)break;
		if(second == 9)
		{
			state = hours;
			l_hours = 0;
			must_be_marker();
			break;
		}
		// seconds 10 & 11 not used
		if(second > 9){state = p_idle;}
		break;


	case hours:  // seconds 12 - 18
		if(second == 14)break;
		if(second == 19)
		{
			state = days;
			l_days = 0;
			must_be_marker();
			break;
		} // end of second 19
	
		// conversion
		if(this_symbol == one)
		{
		if(second == 12) l_hours +=20;
		if(second == 13) l_hours +=10;
		if(second == 15) l_hours +=8;
		if(second == 16) l_hours +=4;
		if(second == 17) l_hours +=2;
		if(second == 18) l_hours +=1;
		} // end of "one" symbol
		if(second > 19)state = p_idle;
		break;
		// second 20 is unused
	case days: // // seconds 21 to 33
		if(second == 24)break; //extra 0
		if(second == 29)	   //marker
			{
			must_be_marker();
			break;
			}
		// seconds 34 & 35 not used
		if(second == 34)break; //unused
		if(second == 35)	   // next data set
		{
			state = DUT1;
			l_dut1_value = 0;
			l_dut1_sign = 0;
			break;
		}
		// convert days
		if(this_symbol == one)
		{
		if(second == 22) l_days +=200;
		if(second == 23) l_days +=100;
		if(second == 25) l_days +=80;
		if(second == 26) l_days +=40;
		if(second == 27) l_days +=20;
		if(second == 28) l_days +=10;
		if(second == 30) l_days +=8;		
		if(second == 31) l_days +=4;
		if(second == 32) l_days +=2;
		if(second == 33) l_days +=1;
		} // end of "one" symbol
		if(second > 35)state = p_idle; 
		break;

	case DUT1:  // seconds 36 to 43
		if(second == 39){must_be_marker(); break;}
		// collect the three bits of the sign stuff
		if((second == 36)&&(this_symbol == one))
			{l_dut1_sign += 1;break;}
		if((second == 37)&&(this_symbol == one))
			{l_dut1_sign += 2; break;}
		if((second == 38)&&(this_symbol == one))
			{l_dut1_sign += 4; break;}
		// second 44 unused always zero 
		if(second == 44)
			{
			state = year;
			l_year = 0;
			break;
			}
		// decode
		if(this_symbol == one)
		{
		if(second == 40) l_dut1_value +=8;
		if(second == 41) l_dut1_value +=4;
		if(second == 42) l_dut1_value +=2;
		if(second == 43) l_dut1_value +=1;
		} // end of symbol equals "one"
		if(second > 44)state = p_idle;
		break;

	case year:	// seconds 45 to 53
		if(second == 49){must_be_marker(); break;}
		// second 54 unused always zero 
		if(second == 54)
			{
			state = leap_year;
			l_leap_year = 0;
			break;
			}
		// convert year
		if(this_symbol == one)
		{
		if(second == 45) l_year +=80;
		if(second == 46) l_year +=40;
		if(second == 47) l_year +=20;
		if(second == 48) l_year +=10;
		if(second == 50) l_year +=8;
		if(second == 51) l_year +=4;
		if(second == 52) l_year +=2;
		if(second == 53) l_year +=1;
		}
//		if(second > 54)state = p_idle; // bug here skips "leap_year"
//										// except never esecuted
		break;

	case leap_year:	// second 55
		if(this_symbol == one)l_leap_year++;
		state = leap_second;
		l_leap_second = 0;
		break;

	case leap_second:	// second 56
		if(this_symbol == one)l_leap_second++;
		state = dst;
		l_dst = 0;
		break;

	case dst:	// seconds 57 & 58
		if(second == 57)
			{
				if(this_symbol == one)l_dst = l_dst +2;
				break;
			}
		if(second == 58)
			{
				if(this_symbol == one) l_dst += 1;
				state = last_second;
				break;
			}
		l_err = 1;	// got to be second 57 or 58
		state = p_idle;
		break;

	case last_second:
		state = first_second;
		d_minutes = l_minutes;
		d_hours = l_hours;
		d_days = l_days;
		d_year = l_year;
		d_dst = l_dst;
		must_be_marker();
		d_update = 0;
		// here is the place to compare last reading to validate the 
		// time read before setting the d_update flag
		if(
			(d_dst == d1_dst)
			&&
			(d_year == d1_year)
			&&
			(d_days == d1_days)
			&&
			(d_hours == d1_hours)
		   )
//			if(d_minutes == d1_minutes+1)
				{			
				d_update = 1;
				}

		//d_update = 1;
		// save for reference next minute
		d1_dst = d_dst;
		d1_year = d_year;
		d1_days = d_days;
		d1_hours = d_hours;
		d1_minutes = d_minutes;
		break;

		
	default:
		init_decode();
	} // end switch

	last_symbol = this_symbol;	// save symbol

// other stuff - check time/move time/ global notify
// not implemented yet 4/25/11


} // end of data_decode

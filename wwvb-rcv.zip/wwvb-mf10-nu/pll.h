// pll.h

void init_PLL(void);
void run_PLL(void);
void sum_phase(void);
int acc_phase(void);
void variance(void);
void gather_data(void);
void solve_pid(void);

/* some variables used in the PLL routine for the
 PID routines
 */
#define pwm_mid_point 512

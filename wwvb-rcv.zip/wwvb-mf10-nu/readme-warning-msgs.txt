Debug build of project `C:\Documents and Settings\joe\My Documents\mf10\mf10.mcp' started.Language tool versions: MPASMWIN.exe v5.40, mplink.exe v4.38, mcc18.exe v3.37.01, mplib.exe v4.38Preprocessor symbol `__DEBUG' is defined.Sun Apr 17 13:41:02 2011----------------------------------------------------------------------Make: The target "C:\Documents and Settings\joe\My Documents\mf10\main.o" is out of date.Executing: "C:\Program Files\Microchip\mplabc18\v3.37.01\bin\mcc18.exe" -p=18F2620 /i"C:\Program Files\Microchip\mplabc18\v3.37.01\h" "main.c" -fo="main.o" -D__DEBUG -Ou- -Ot- -Ob- -Op- -Or- -Od- -Opa-MPLAB C18 v3.37.01 (evaluation)Copyright 2000-2010 Microchip Technology Inc.Days remaining until evaluation becomes feature limited:  41C:\Documents and Settings\joe\My Documents\mf10\main.c:301:Warning [2066] type qualifier mismatch in assignmentC:\Documents and Settings\joe\My Documents\mf10\main.c:315:Warning [2066] type qualifier mismatch in assignmentMake: The target "C:\Documents and Settings\joe\My Documents\mf10\comm.o" is up to date.Make: The target "C:\Documents and Settings\joe\My Documents\mf10\lcd_cntl.o" is up to date.Make: The target "C:\Documents and Settings\joe\My Documents\mf10\ad.o" is up to date.Make: The target "C:\Documents and Settings\joe\My Documents\mf10\pwm.o" is up to date.Make: The target "C:\Documents and Settings\joe\My Documents\mf10\data_decode.o" is up to date.Make: The target "C:\Documents and Settings\joe\My Documents\mf10\mf10.cof" is out of date.Executing: "C:\Program Files\Microchip\mplabc18\v3.37.01\bin\mplink.exe" /p18F2620 /l"C:\Program Files\Microchip\mplabc18\v3.37.01\lib" /k"C:\Program Files\Microchip\mplabc18\v3.37.01\bin\LKR" "main.o" "comm.o" "lcd_cntl.o" "ad.o" "pwm.o" "data_decode.o" /u_CRUNTIME /u_DEBUG /z__MPLAB_BUILD=1 /z__MPLAB_DEBUG=1 /o"mf10.cof" /M"mf10.map" /WMPLINK 4.38, LinkerCopyright (c) 1998-2010 Microchip Technology Inc.Errors    : 0MP2HEX 4.38, COFF to HEX File ConverterCopyright (c) 1998-2010 Microchip Technology Inc.Errors    : 0Loaded C:\Documents and Settings\joe\My Documents\mf10\mf10.cof.----------------------------------------------------------------------Debug build of project `C:\Documents and Settings\joe\My Documents\mf10\mf10.mcp' succeeded.Language tool versions: MPASMWIN.exe v5.40, mplink.exe v4.38, mcc18.exe v3.37.01, mplib.exe v4.38Preprocessor symbol `__DEBUG' is defined.Sun Apr 17 13:41:10 2011----------------------------------------------------------------------BUILD SUCCEEDED




I'm getting the compiler warning
Warning [2066] type qualifier mismatch in assignment
two places in my code. I want to learn why and how to do it right.

One is from something like this:

 putrsUSART("mystring ");
 



This one is particularly confusing because this is exactly how the MPLAB C18 Compiler Libraries document gives the example for putrsUSART().

The other is from

 (* ouside of main *)
 char small_global_array[5];
 ...
 (* inside main *)
 strcpypgm2ram( small_global_array, "AB \0");
 



Is there something I should be doing differently?
#1
jtemples
Super Member

    * Total Posts : 6275
    * Reward points : 0
    * Joined: 2/13/2004
    * Location: Southern California
    * Status: offline

	

    * Reply to message
    * Message Options

RE: type qualifier mismatch warning - Thursday, September 16, 2004 8:57 PM ( #2 )
The compiler libraries are built with the large memory model (far rom pointers) while the compiler uses the near memory
 model (near rom pointers) by default, unless you compile with -ml. The compiler is complaining that you're
 passing a 16-bit pointer to a string constant to a function that expects a 24-bit pointer.
 The compiler knows how to perform that conversion, so the code will work correctly even with the warning.
 Most any random char* cast applied to the string literal will suppress the warning while still generating
 correct code. The correct cast is (const rom far char *), but incorrect casts like (char *) will work,
 and even meaningless casts like (near far rom rom rom char *) will work.

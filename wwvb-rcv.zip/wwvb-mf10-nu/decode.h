/* data_decode.h	support header for decode */


void init_decode(void);
void data_decode(int d_time);



// interval of the data symbols

#define r_zero 10		// 10 intervals of 20ms = 200 ms
#define r_one  25		// 25 intervals of 20ms = 500 ms
#define r_marker 40		// 40 intervals of 20ms = 800 ms
#define m_zero 5
#define m_one 18
#define m_marker 30

// define the symbol

#define zero 1		// in code as symbol
#define one  2
#define marker 3

// define the states of the decode

#define p_idle 0		// after init - wait for two markers
#define minutes 1		// interval 1 to 8
#define hours 2			// interval 10 - 18
#define days 3			// interval 20 - 34
#define DUT1 4			// interval 35 - 44
#define year 5			// interval 45 - 54
#define leap_year 6 	// interval 55
#define leap_second 7	// interval 56 
#define dst 8			// interval 57 - 58
#define last_second 9	// interval 59
#define first_second 10 // interval 0
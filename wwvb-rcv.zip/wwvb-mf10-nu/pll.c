// pll.c -- average the phase angle readings and drive
//			the Vt

#include <string.h>
#include <p18f2620.h>
#include "stdlib.h"
#include "stdio.h"
#include "comm.h"
#include "lcd_cntl.h"
#include "pwm.h"
#include "main.h"
#include "ad.h"
#include "decode.h"
#include "pll.h"

extern int I_signal,Q_signal;

/*
The ISR reads the A/D channel #0 for the In-phase voltage
 and the Q_phase_signal voltage
 the reading is make at 0.9 seconds in the one second symbol period
This reading is a value between 0 & 5000 - it is the voltage in millivolts.

This module will average the voltage in groups of: 1,2,4,8 and
16 and divide as needed.

A PID value is calculated to the PWM
NOTE: the PWM has a value 0 - 1024.
*/

// ------------- local storage -----------------------
int phase_index =0;
#define phase_max 16
int phase[16];
long phase_sum;
long variance_sum;
int dsp_variance;	// for display
int pll_state = 0;	// state determines length of average
int sample_count=0; // number of samples used in LP filter
int v_phase;            // pre-processed I_signal & Q_signal
					// switching
int samples_per_state[6]= {0,1,2,4,8,16};
int shifts_per_state[6] = {0,0,1,2,3,4};

// variables used in the PID solutions
int pid_results;        // includes the PWM_mid_point value
int pid_integrator;
int pid_derivative;
int pid_derivative_last_value=0;

int p_scale_factor[6] = {0,1,2,3,3,3};
int i_scale_factor[6] = {4,5,5,5,6,7};
int d_scale_factor[6] = {1,2,3,4,4,5};

/*
PLL states defined
0. Initial state - sets up X1
1. Drives PWM with input for 100 samples.
   Then switches to state 2 for average of two counts
   for 100 samples unless an error is detected.
2. Drives PWM with average of 2 samples (as above)
3. Drives PWM with average of 4 samples
4. Drives PWM with average of 8 samples
5. Drives PWM with average of 16 samples
*/

void init_PLL(void)
{
	int i;
	pll_state = 1;
	sample_count = 100;
	phase_sum =0;
	phase_index = 0;
	variance_sum = 0;
	dsp_variance = 0;
        pid_integrator = 0;
        pid_derivative = 0;
        pid_results = 0;
	for(i=0;i<phase_max;i++)phase[i]=0;
}

void run_PLL(void)
{
/*   This routine is called at 0.9 seconds in the one second interval
 *   pre-process the I_signal and the Q_signal to form v_phase.
 *   v_phase is a value of the Q signal that is forced to be in
 *   quadrent 1 or quadrent 4 of the standard circle.
 *  The A/D reading is normalized 0 - 5000 ( 0 to 5.0 volts in millivolts)
 *  The phase detectors operate to give zero at 2500 (2.5 volts) any other
 *  value is + 0 to 90 degrees or - 0- 90 degrees. The I and the Q signals
 *  are treated as being points on the XY plane to represent the vector
 *  value of the phase angle. Rather than go to an arctan routine the signal
 *  is tested to be in either the first quadrent or the fourth. If it is not
 *  it is forced to be rotated 180 (pi) degrees.
 *  The current rule - if I_signal > 2.5 v use unmodified Q_signal
 *  else fold Q_signal around the A/D mid range of 0 - 5000.
 *  The Q signal becomes a representation of the tan of the phase angle in
 *  the range of + and - 90 degrees. This is used to zero the VCXO phase with
 *  respect to the Q signal.
*/
    if(I_signal > 2500) v_phase = Q_signal;     // if I signal + take Q as is
    else
    {
        if(Q_signal > 2500){            // if I signal - invert the Q signal
            v_phase = Q_signal - 2500;  // if Q is positive make negative
            v_phase = ~v_phase+1;       // ie less than 2500
            v_phase = v_phase + 2500;
        }
        else
        {
            v_phase = (2500 - Q_signal) + 2500;
        }
    }

	switch(pll_state)
	{
	case 1: // one sample
                gather_data();
		load_pwm(pid_results);
		sample_count--;
		if(sample_count <=0)
			{ // setup state 2
			pll_state++;
			sample_count = 100;
			phase_index = 0;
			}
		break;
	case 2: // 2 samples
		gather_data();
		load_pwm(pid_results);
		if(--sample_count ==0)
			{
			pll_state++;
			sample_count = 100;
			}
		break;
	case 3:	// 4 samples
		gather_data();
		load_pwm(pid_results);
		if(--sample_count ==0)
			{
			pll_state++;
			sample_count = 100;
			}
		break;
	case 4:	// 8 samples
		gather_data();
		// check variance
		load_pwm(pid_results);
		if(--sample_count ==0)
			{
			pll_state++;
			sample_count = 100;
			}
		break;
	case 5:	// 16 samples
		gather_data();
		// check variance
		if(sample_count != 0)
		{
		sample_count--;
		}
		else
		{
                    if(variance_sum > 300)	// can change this if needed
                    {
                    pll_state=1;			// re-acquire the phase lock
                    sample_count = 100;
                    } // end variance_sum
		} // end of else
		load_pwm(pid_results);
		break;

	} // end switch
} // end run_PLL

//-------------------- helper routines -------------------

void gather_data(void){
	acc_phase();
	sum_phase();
	variance();
        solve_pid();
       // pid_results = phase_sum;
}

// sum the phase voltage array and compute average

void sum_phase(void)
{
	int i;
	int max;
	max = samples_per_state[pll_state];
	phase_sum = 0;
	for(i=0;i<max;i++)phase_sum += phase[i];
	phase_sum = phase_sum >> shifts_per_state[pll_state];
} // end of sum_phase

// accumulate phase voltage in an array
int acc_phase(void)
{
	phase[phase_index] = v_phase;
	phase_index++;
	if(phase_index > phase_max)phase_index = 0; // check for problems
	if(phase_index == samples_per_state[pll_state])
		{
		phase_index = 0;
		return 1;
		}
	return 0;

} // end of acc_phase

// compute variance (without the swrt) of phase array

void variance(void)
{
int i,j,temp;

j = samples_per_state[pll_state];
variance_sum = 0;
for(i=0;i<j;i++)
{
	temp = phase[i] - phase_sum;	// phase_sum is really an average
	if(temp < 0) temp = ~temp +1;	// if negative twos comp
	variance_sum += temp;
}
variance_sum = variance_sum >> shifts_per_state[pll_state];
// variance is now the average variance of N samples
dsp_variance = (int) variance_sum; // make int for display
}	// end variance

// Solve the PID equations for the state of the PLL filter
void solve_pid(void)
{
    int pid_temp;
    int scaled_temp;
    //pid_temp = v_phase - 2500; // make value a signed number
        pid_temp = phase_sum - 2500; // make value a signed number
    if(pid_temp < 0)
    {
        scaled_temp = -pid_temp;
        scaled_temp = scaled_temp >> p_scale_factor[pll_state];
        scaled_temp = -scaled_temp;
    }
    else scaled_temp = pid_temp >> p_scale_factor[pll_state];

    pid_results = scaled_temp;  // add porportinal factor
    //tty_display_digits_no_cr(scaled_temp);
    
    pid_integrator += pid_temp; // add sum to integrator
    if(pid_integrator > 16000)pid_integrator = 16000;
    if(pid_integrator < -16000)pid_integrator = -16000;

    pid_derivative = pid_temp - pid_derivative_last_value;
    pid_derivative_last_value = pid_temp;

    if(pid_integrator < 0)
    {
        scaled_temp = -pid_integrator;
        scaled_temp = scaled_temp >> i_scale_factor[pll_state];
        scaled_temp = -scaled_temp;
    }
    else scaled_temp = pid_integrator >> i_scale_factor[pll_state];
    pid_results += scaled_temp; // add integrator to result
    //tty_display_digits_no_cr(scaled_temp);

    if(pid_derivative < 0)
    {
        scaled_temp = -pid_derivative;
        scaled_temp = scaled_temp >> d_scale_factor[pll_state];
        scaled_temp = -scaled_temp;
    }
    else scaled_temp = pid_derivative >> d_scale_factor[pll_state];
    pid_results += scaled_temp;     // add derivative to result
   // tty_display_digits_no_cr(scaled_temp);
    pid_results += pwm_mid_point;   // add setpoint to result
    
    if(pid_results > 1024)pid_results = 1023;
    if(pid_results < 0)pid_results = 0;

   // tty_display_digits_no_cr(p_scale_factor[pll_state]);
   // tty_display_digits(pid_results);
}// end solve pid
	

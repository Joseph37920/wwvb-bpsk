/* A/D routines */
//#include <p18f4525.h>
#include <p18f2620.h>
#include "ad.h"
//#include "monitor.h"
static ram long  cal_const = 4883; // assume 5.0 volt reference

// ------------------ calibrate routine ------------------
void ad_cal(int vref)
{
long tmp;
	// test zero or range 3 - 5 volts
	if(vref == 0){cal_const = 4883; return;}
	if((vref > 550)|(vref < 300)){cal_const = 4883; return;}
	// 
	tmp = (long)vref * 1000000;	// input voltage constant scaled d6
	tmp = tmp/102400;		// A/D counts * 100
	cal_const = tmp;		// should be a number in the 3 - 5 thousand range
}


// ------------------ read A/D channel x -----------------
int read_ad(unsigned char ch){

int reading;
long tmp;
	// check channel 0 - 3
	if((ch > 3)|(ch < 0)) return -1;
	// insert into ad start byte
	ADCON0 = (ch <<2) + 3; // channel ch, ad on & start conversion
	while(ADCON0bits.GO);	// wait for conversion
	tmp = ADRESH;
	tmp = (tmp  << 8) | ADRESL;
	tmp = tmp * cal_const/1000;	// voltage in millivolts
	reading = (int)tmp;
//		xprintf("C = %d V = %d\n",(int)ch,(int) reading);
	// return reading in millivolts
	return reading;
}


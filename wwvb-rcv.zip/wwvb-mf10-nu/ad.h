/* A/D routines header */

void ad_cal(int vref);	// calibrate A/D to vref
int read_ad(unsigned char ch);	// return channel 0-3 in millivolts


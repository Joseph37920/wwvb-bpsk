This folder is the holding point for all the documentation about the WWVB receiver
using the MF10 filter chips and the SA612 balanced modulator to build a "superhet"
receiver with an IF of 2500 hertz.

Save all the "sch" drawings as "png" to put into the documentation.


